package manueAndLogin;

public interface EventMenuButton {

    public void press(int idx);
}
