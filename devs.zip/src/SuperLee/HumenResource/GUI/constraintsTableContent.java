package SuperLee.HumenResource.GUI;

public class constraintsTableContent
{
    public static Object[][] data = {
            {false, false, false, false, false, false, false, false},
            {false, false, false, false, false, false, false, false},
    };
    public static String[] columnNames = {"", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};


}
