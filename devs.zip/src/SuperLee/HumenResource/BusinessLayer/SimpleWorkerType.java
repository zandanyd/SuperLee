package SuperLee.HumenResource.BusinessLayer;

import java.sql.Array;

public enum SimpleWorkerType  {
        Cashier, StockKeeper,GeneralWorker,Cleaner ,Usher;
}
