package SuperLee.HumenResource.BusinessLayer;

public enum ShiftType {
    Morning, Evening;
}
