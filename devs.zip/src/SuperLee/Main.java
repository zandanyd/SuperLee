package SuperLee;
import SuperLee.HumenResource.PrasrntationLayer.UserInterface;


import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException {
       UserInterface.Start(false, false,false);

    }

}
