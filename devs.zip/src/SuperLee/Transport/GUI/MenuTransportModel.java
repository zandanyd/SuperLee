package SuperLee.Transport.GUI;

public class MenuTransportModel {
}
