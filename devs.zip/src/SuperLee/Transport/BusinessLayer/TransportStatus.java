package SuperLee.Transport.BusinessLayer;
public enum TransportStatus {
    IN_TRANSIT, DONE
}
