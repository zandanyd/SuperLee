package SuperLee.Transport.BusinessLayer;
public enum TrainingType {
    REFRIGERATED, FROZEN, DRY
}
