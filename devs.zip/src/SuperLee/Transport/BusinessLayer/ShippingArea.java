package SuperLee.Transport.BusinessLayer;
public enum ShippingArea {
    SOUTH,
    CENTRAL,
    NORTH
}
