package SuperLee.Transport.BusinessLayer;
public enum OrderStatus {
    PENDING,  SELECTED_FOR_TRANSPORT, CLOSE
}
